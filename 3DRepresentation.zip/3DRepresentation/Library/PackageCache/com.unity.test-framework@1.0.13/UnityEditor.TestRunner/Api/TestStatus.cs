namespace UnityEditor.TestTools.TestRunner.Api
{
    internal enum TestStatus
    {
        Skipped,
        Passed,
        Failed,
        Inconclusive
    }
}
